﻿//  --------------------------------------------------------------------------------------
// CarLoans.LoanCalculator.cs
//  --------------------------------------------------------------------------------------

namespace CarLoans
{
    public class LoanCalculator
    {
        public int Additionofnumbers(int anumber, int anothernumber)
        {
            return anumber + anothernumber;
        }
    }
}