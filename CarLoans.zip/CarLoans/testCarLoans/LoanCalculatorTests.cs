﻿
//  --------------------------------------------------------------------------------------
//   loan Calculator Tests.cs
//  --------------------------------------------------------------------------------------

using CarLoans;
using NUnit.Framework;

  namespace testCarLoans
{
    [TestFixture]
    public class LoanCalculatorTests
    {
        [TestCase(1, 2)]
        [TestCase(2, 3)]
        [TestCase(3, 5)]
        [TestCase(1000, 1)]
        public void AdditionReturnsExpectedvalue(int anumber, int anothernubmer)
        {
            var systemUnderTest = new LoanCalculator();
            var Correctresults = anumber + anothernubmer;
            Assert.That(systemUnderTest.Additionofnumbers(anumber, anothernubmer), Is.EqualTo(Correctresults));
        }
    }
}